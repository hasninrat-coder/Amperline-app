# Amperline Player

## Option A: Install as an app (no build, 2 minutes)
1. Upload the `www` folder to any HTTPS host (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. Open the URL in Chrome on your phone -> menu -> "Install app" / "Add to Home screen".
It then runs full screen with its own icon and works offline.

## Option B: Real Android APK
Needs Node.js 18+ and Android Studio.
1. `npm install`
2. `npm run android`  (adds the Android project and opens Android Studio)
3. In Android Studio: Build -> Build APK(s). Install the APK on your phone.

## Option C: Windows/Mac/Linux desktop
Install the PWA from Chrome or Edge (address bar install icon), or wrap `www` with Electron/Tauri.

## Option D: Get the APK with no tools (GitHub)
1. Create a free GitHub repo and upload everything in this folder (including `.github`).
2. Open the Actions tab -> "Build APK" -> wait about 5 minutes.
3. Download `amperline-apk` from the run, unzip it, and install `app-debug.apk` on your phone (allow "Install unknown apps").
